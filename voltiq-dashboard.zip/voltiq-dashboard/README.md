# VOLTIQ Story Dashboard
วิชา Business Idea Creation · VOLTIQ — Smart Energy, Effortless Living

## รายชื่อกลุ่ม
| ลำดับ | ชื่อ-นามสกุล | รหัสนักศึกษา |
|---|---|---|
| 1 | (ใส่ชื่อ) | (ใส่รหัส) |
| 2 | (ใส่ชื่อ) | (ใส่รหัส) |

## โครงสร้าง Repository
- `index.html` — Dashboard เชิงเล่าเรื่อง (เปิดในเบราว์เซอร์ได้เลย)
- `data/hourly_load_tou.csv` — โหลดไฟรายชั่วโมง, ราคา TOU, โซลาร์ (ก่อน/หลังใช้ AI)
- `data/cost_structure.csv` — สัดส่วนต้นทุน
- `data/ai_actions.csv` — การสั่งการของ AI และเงินที่ประหยัดได้ต่อวัน

## สมมติฐาน
ข้อมูลทั้งหมดเป็นค่าสมมติเพื่อการจำลอง: TOU Peak 5.80 / Off-Peak 2.64 บาท/kWh, โซลาร์ 3.8 kW ควรแทนด้วยข้อมูลจริงจากแหล่งอ้างอิงก่อนส่ง
